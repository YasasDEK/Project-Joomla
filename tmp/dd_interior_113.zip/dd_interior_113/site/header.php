<header class=" bd-headerarea-1  bd-margins">
        <?php
    renderTemplateFromIncludes('hmenu_6', array());
?>
</header>