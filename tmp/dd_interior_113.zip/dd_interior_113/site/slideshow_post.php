
<style>
.bd-slide-11 {background-image: url(<?php echo JURI::base()?>/<?php echo $document->params->get('sp1-1'); ?>);}
.bd-slide-2 {background-image: url(<?php echo JURI::base()?>/<?php echo $document->params->get('sp2-1'); ?>);}

</style>

<div class="bd-containereffect-28 container-effect container "><section class=" bd-section-28 bd-tagstyles " id="slideshow_post" data-section-title="slideshow_post">
    <div class="bd-container-inner bd-margins clearfix">
        <div id="carousel-2" class="bd-slider-2 bd-slider bd-no-margins  carousel slide bd-carousel-fade" >
    

    

    
        
    <div class="bd-sliderindicators-2  bd-slider-indicators" >
    <ol class="bd-indicators-17 bd-no-margins " >
        
        <li><a class="
 active" href="#" data-target="#carousel-2" data-slide-to="0"></a></li>
        <li><a class="" href="#" data-target="#carousel-2" data-slide-to="1"></a></li>
        
    </ol>
    </div>

    <div class="bd-slides carousel-inner">
        <div class=" bd-slide-11 bd-textureoverlay bd-textureoverlay-5 bd-slide item"
    
    
    >
    <div class="bd-container-inner">
        <div class="bd-container-inner-wrapper">
            <h1 class=" bd-textblock-19 bd-content-element">
<?php echo $document->params->get('sp1-2'); ?>
</h1>
        </div>
    </div>
</div>
	
		<div class=" bd-slide-2 bd-textureoverlay bd-textureoverlay-8 bd-slide item"
    
    
    >
    <div class="bd-container-inner">
        <div class="bd-container-inner-wrapper">
            <h1 class=" bd-textblock-5 bd-content-element">
<?php echo $document->params->get('sp2-2'); ?>
</h1>
        </div>
    </div>
</div>
</div>

    
        <div class="bd-left-button">
    <a class=" bd-carousel" href="#">
        <span class="bd-icon"></span>
    </a>
</div>

<div class="bd-right-button">
    <a class=" bd-carousel" href="#">
        <span class="bd-icon"></span>
    </a>
</div>

    

    

    <script type="text/javascript">
        /* <![CDATA[ */
        if ('undefined' !== typeof initSlider) {
            initSlider(
                '.bd-slider-2',
                {
                    leftButtonSelector: 'bd-left-button',
                    rightButtonSelector: 'bd-right-button',
                    navigatorSelector: '.bd-carousel',
                    indicatorsSelector: '.bd-indicators-17',
                    carouselInterval: 4700,
                    carouselPause: "hover",
                    carouselWrap: true,
                    carouselRideOnStart: true
                }
            );
        }
        /* ]]> */
    </script>
</div>
    </div>
</section></div>