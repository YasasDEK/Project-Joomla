<footer class=" bd-footerarea-1 bd-margins">
        <section class=" bd-section-14 bd-page-width bd-tagstyles " id="section4" data-section-title="Footer Four Columns Dark">
    <div class="bd-container-inner bd-margins clearfix">
        <div class=" bd-layoutcontainer-52 bd-page-width  bd-columns bd-no-margins">
    <div class="bd-container-inner">
        <div class="container-fluid">
            <div class="row 
 bd-row-flex 
 bd-row-align-top">
                <div class=" bd-columnwrapper-128 
 col-lg-3
 col-md-3
 col-sm-6">
    <div class="bd-layoutcolumn-128 bd-column" ><div class="bd-vertical-align-wrapper"><h2 class=" bd-textblock-26 bd-no-margins bd-content-element">
<?php echo $document->params->get('fo-1'); ?>
</h2>
	
		<div class=" bd-spacer-2 clearfix"></div>
	
		<p class=" bd-textblock-28 bd-content-element">
    <?php echo $document->params->get('fo-2'); ?><br>
<a class="bd-linkbutton-17 bd-no-margins  bd-button-171 bd-icon bd-icon-101 bd-own-margins bd-content-element" href="<?php echo $document->params->get('fo-4'); ?>">
    <?php echo $document->params->get('fo-3'); ?></a>            
</p></div></div>
</div>
	
		<div class=" bd-columnwrapper-130 
 col-lg-3
 col-md-3
 col-sm-6">
    <div class="bd-layoutcolumn-130 bd-column" ><div class="bd-vertical-align-wrapper"><h2 class=" bd-textblock-30 bd-no-margins bd-content-element">
 <?php echo $document->params->get('fom-header'); ?></a> 
</h2>
	
		<div class=" bd-spacer-8 clearfix"></div>
	
		<p class=" bd-textblock-33 bd-no-margins bd-content-element">
  
<a href="<?php echo $document->params->get('fom-2'); ?>" draggable="false"><?php echo $document->params->get('fom-1'); ?></a>

</p>
	
		<div class="bd-separator-5  bd-separator-center bd-separator-content-center clearfix" >
    <div class="bd-container-inner">
        <div class="bd-separator-inner">
            
        </div>
    </div>
</div>
	
		<p class=" bd-textblock-35 bd-no-margins bd-content-element">
   
<a href="<?php echo $document->params->get('fom-3'); ?>" draggable="false"><?php echo $document->params->get('fom-3'); ?></a>

</p>
	
		<div class="bd-separator-11  bd-separator-center bd-separator-content-center clearfix" >
    <div class="bd-container-inner">
        <div class="bd-separator-inner">
            
        </div>
    </div>
</div>
	
		<p class=" bd-textblock-37 bd-no-margins bd-content-element">

<a href="<?php echo $document->params->get('fom-6'); ?>"><?php echo $document->params->get('fom-5'); ?></a>

</p>
	
		<div class="bd-separator-15  bd-separator-center bd-separator-content-center clearfix" >
    <div class="bd-container-inner">
        <div class="bd-separator-inner">
            
        </div>
    </div>
</div></div></div>
</div>
	
		<div class=" bd-columnwrapper-134 
 col-lg-2
 col-md-3
 col-sm-6">
    <div class="bd-layoutcolumn-134 bd-column" ><div class="bd-vertical-align-wrapper"><h2 class=" bd-textblock-49 bd-no-margins bd-content-element">
<?php echo $document->params->get('foc-header'); ?>
</h2>
	
		<div class=" bd-spacer-15 clearfix"></div>
	
		<div class=" bd-layoutbox-28 bd-no-margins clearfix">
    <div class="bd-container-inner">
        <span class="bd-iconlink-2 bd-own-margins bd-icon-120 bd-icon "></span>
	
		<p class=" bd-textblock-51 bd-no-margins bd-content-element">

<?php echo $document->params->get('foc-1'); ?>,<br><?php echo $document->params->get('foc-2'); ?>

</p>
    </div>
</div>
	
		<div class=" bd-spacer-17 clearfix"></div>
	
		<div class=" bd-layoutbox-30 bd-no-margins clearfix">
    <div class="bd-container-inner">
        <span class="bd-iconlink-5 bd-own-margins bd-icon-123 bd-icon "></span>
	
		<p class=" bd-textblock-53 bd-no-margins bd-content-element">

<?php echo $document->params->get('foc-3'); ?><br>
<?php echo $document->params->get('foc-4'); ?>

</p>
    </div>
</div>
	
		<div class=" bd-spacer-19 clearfix"></div>
	
		<div class=" bd-layoutbox-32 bd-no-margins clearfix">
    <div class="bd-container-inner">
        <span class="bd-iconlink-7 bd-own-margins bd-icon-126 bd-icon "></span>
	
		<p class=" bd-textblock-55 bd-no-margins bd-content-element">

<a href="mailto:<?php echo $document->params->get('foc-5'); ?>"><?php echo $document->params->get('foc-5'); ?></a>
<br><a href="<?php echo $document->params->get('foc-6'); ?>" target="blank"><?php echo $document->params->get('foc-6'); ?></a>

</p>
    </div>
</div></div></div>
</div>
	
		<div class=" bd-columnwrapper-132 
 col-lg-4
 col-md-3
 col-sm-6">
    <div class="bd-layoutcolumn-132 bd-column" ><div class="bd-vertical-align-wrapper"><div class="bd-googlemap-4 bd-own-margins bd-imagestyles-153 ">
    <div class="embed-responsive" style="height: 100%; width: 100%;">
        <iframe class="embed-responsive-item" src="//maps.google.com/maps?output=embed&q=<?php echo $document->params->get('fom1'); ?>, <?php echo $document->params->get('fom2'); ?>&t=m"></iframe>
    </div>
</div></div></div>
</div>
            </div>
        </div>
    </div>
</div>
    </div>
</section>
	
		<section class=" bd-section-5 bd-tagstyles" id="section5" data-section-title="Section">
    <div class="bd-container-inner bd-margins clearfix">
        <p class=" bd-textblock-4 bd-content-element">
<?php echo date("Y");?> © <?php echo $document->params->get('footer1'); ?> All Rights Reserved.
</p>
    </div>
</section>
	

</footer>